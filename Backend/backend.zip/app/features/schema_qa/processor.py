import os
import json
import yaml
import logging
from typing import Dict, List, Optional, Any
from langchain.schema import Document
from app.core.config import settings
from app.services.hybrid_store import HybridStorageManager

logger = logging.getLogger(__name__)

class SchemaProcessor:
    def __init__(self, hybrid_store: HybridStorageManager):
        self.hybrid_store = hybrid_store
        self.supported_types = settings.SCHEMA_TYPES

    def process_schema(self, schema_content: str, schema_type: str) -> bool:
        """Process schema content and create embeddings"""
        try:
            if schema_type not in self.supported_types:
                raise ValueError(f"Unsupported schema type: {schema_type}")

            # Parse schema based on type
            if schema_type == "sql":
                return self._process_sql_schema(schema_content)
            elif schema_type == "json":
                return self._process_json_schema(schema_content)
            elif schema_type == "yaml":
                return self._process_yaml_schema(schema_content)
            elif schema_type == "graphql":
                return self._process_graphql_schema(schema_content)
            
            return False
        except Exception as e:
            logger.error(f"Error processing schema: {str(e)}")
            return False

    def _process_sql_schema(self, schema_content: str) -> bool:
        """Process SQL schema"""
        try:
            # Split into individual statements
            statements = schema_content.split(';')
            
            for statement in statements:
                statement = statement.strip()
                if not statement:
                    continue

                # Create document with metadata
                doc = Document(
                    page_content=statement,
                    metadata={
                        "type": "sql",
                        "statement_type": self._get_sql_statement_type(statement),
                        "tables": self._extract_tables_from_sql(statement),
                        "relationships": self._extract_relationships_from_sql(statement)
                    }
                )
                
                # Add to schema store
                self.hybrid_store.add_document(doc, store_type="schema")
            
            return True
        except Exception as e:
            logger.error(f"Error processing SQL schema: {str(e)}")
            return False

    def _process_json_schema(self, schema_content: str) -> bool:
        """Process JSON schema"""
        try:
            if isinstance(schema_content, str):
                schema = json.loads(schema_content)
            else:
                schema = schema_content
            # Flexible root detection
            schema_root = self._find_schema_root(schema)
            # Process each table/collection
            for table_name, table_schema in schema_root.items():
                doc = Document(
                    page_content=json.dumps(table_schema, indent=2),
                    metadata={
                        "type": "json",
                        "table_name": table_name,
                        "fields": list(table_schema.keys()) if isinstance(table_schema, dict) else [],
                        "relationships": self._extract_json_relationships(table_schema) if isinstance(table_schema, dict) else []
                    }
                )
                self.hybrid_store.add_document(doc, store_type="schema")
            return True
        except Exception as e:
            logger.error(f"Error processing JSON schema: {str(e)}")
            return False

    def _process_yaml_schema(self, schema_content: str) -> bool:
        """Process YAML schema"""
        try:
            schema = yaml.safe_load(schema_content)
            
            # Process each table/collection
            for table_name, table_schema in schema.items():
                doc = Document(
                    page_content=yaml.dump(table_schema),
                    metadata={
                        "type": "yaml",
                        "table_name": table_name,
                        "fields": list(table_schema.keys()),
                        "relationships": self._extract_yaml_relationships(table_schema)
                    }
                )
                
                self.hybrid_store.add_document(doc, store_type="schema")
            
            return True
        except Exception as e:
            logger.error(f"Error processing YAML schema: {str(e)}")
            return False

    def _process_graphql_schema(self, schema_content: str) -> bool:
        """Process GraphQL schema"""
        try:
            # Split into type definitions
            type_defs = schema_content.split('type')
            
            for type_def in type_defs:
                type_def = type_def.strip()
                if not type_def:
                    continue

                # Extract type name and fields
                type_name = type_def.split('{')[0].strip()
                fields = type_def.split('{')[1].split('}')[0].strip()
                
                doc = Document(
                    page_content=type_def,
                    metadata={
                        "type": "graphql",
                        "type_name": type_name,
                        "fields": self._extract_graphql_fields(fields),
                        "relationships": self._extract_graphql_relationships(fields)
                    }
                )
                
                self.hybrid_store.add_document(doc, store_type="schema")
            
            return True
        except Exception as e:
            logger.error(f"Error processing GraphQL schema: {str(e)}")
            return False

    def _get_sql_statement_type(self, statement: str) -> str:
        """Determine the type of SQL statement"""
        statement = statement.lower()
        if statement.startswith('create table'):
            return 'create_table'
        elif statement.startswith('alter table'):
            return 'alter_table'
        elif statement.startswith('create index'):
            return 'create_index'
        elif statement.startswith('create view'):
            return 'create_view'
        return 'unknown'

    def _extract_tables_from_sql(self, statement: str) -> List[str]:
        """Extract table names from SQL statement"""
        # This is a simplified version - you might want to use a proper SQL parser
        tables = []
        statement = statement.lower()
        
        if 'create table' in statement:
            table_name = statement.split('create table')[1].split('(')[0].strip()
            tables.append(table_name)
        elif 'alter table' in statement:
            table_name = statement.split('alter table')[1].split(' ')[0].strip()
            tables.append(table_name)
        
        return tables

    def _extract_relationships_from_sql(self, statement: str) -> List[Dict]:
        """Extract relationships from SQL statement"""
        relationships = []
        statement = statement.lower()
        
        if 'foreign key' in statement:
            # Extract foreign key relationships
            fk_parts = statement.split('foreign key')
            for part in fk_parts[1:]:
                if 'references' in part:
                    ref_parts = part.split('references')
                    if len(ref_parts) >= 2:
                        relationships.append({
                            'type': 'foreign_key',
                            'source': ref_parts[0].strip(),
                            'target': ref_parts[1].split('(')[0].strip()
                        })
        
        return relationships

    def _extract_json_relationships(self, schema: Dict) -> List[Dict]:
        """Extract relationships from JSON schema"""
        relationships = []
        
        for field_name, field_schema in schema.items():
            if isinstance(field_schema, dict) and 'type' in field_schema:
                if field_schema['type'] == 'reference':
                    relationships.append({
                        'type': 'reference',
                        'field': field_name,
                        'target': field_schema.get('target', '')
                    })
        
        return relationships

    def _extract_yaml_relationships(self, schema: Dict) -> List[Dict]:
        """Extract relationships from YAML schema"""
        # Similar to JSON relationships
        return self._extract_json_relationships(schema)

    def _extract_graphql_fields(self, fields: str) -> List[str]:
        """Extract field names from GraphQL type definition"""
        return [field.split(':')[0].strip() for field in fields.split('\n') if field.strip()]

    def _extract_graphql_relationships(self, fields: str) -> List[Dict]:
        """Extract relationships from GraphQL type definition"""
        relationships = []
        
        for field in fields.split('\n'):
            field = field.strip()
            if not field:
                continue
                
            if ':' in field:
                field_name, field_type = field.split(':')
                field_name = field_name.strip()
                field_type = field_type.strip()
                
                # Check if it's a relationship field
                if field_type.startswith('[') and field_type.endswith(']'):
                    relationships.append({
                        'type': 'one_to_many',
                        'field': field_name,
                        'target': field_type[1:-1]
                    })
                elif not field_type.startswith('[') and field_type[0].isupper():
                    relationships.append({
                        'type': 'one_to_one',
                        'field': field_name,
                        'target': field_type
                    })
        
        return relationships

    def _find_schema_root(self, schema: dict) -> dict:
        """Detect the schema root for flexible user-uploaded schemas."""
        # If all or most top-level values are dicts, treat schema as root
        dict_keys = [k for k, v in schema.items() if isinstance(v, dict)]
        if len(dict_keys) == len(schema):
            return schema
        if len(dict_keys) > 0 and len(dict_keys) >= len(schema) // 2:
            return schema
        # If only one value is a dict and others are metadata, use that as root
        if len(dict_keys) == 1:
            return schema[dict_keys[0]]
        # Otherwise, not a supported structure
        raise ValueError("Could not detect schema root. Please upload a JSON where the top-level keys are tables/collections, or all tables are under a single key.") 
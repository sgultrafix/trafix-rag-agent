from fastapi import FastAPI, UploadFile, File, HTTPException, Body, Query
from fastapi.middleware.cors import CORSMiddleware
import logging
from app.core.config import settings
from app.core.utils import save_upload_file
from app.services.rag_service import RAGService
from app.services.hybrid_store import HybridStorageManager
from app.features.schema_qa.service import SchemaQAService
import os
import shutil
import time
from app.api.health import router as health_router
from app.api.schema_upload import router as schema_upload_router
from fastapi import BackgroundTasks
from typing import Dict

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

app = FastAPI(
    title=settings.PROJECT_NAME,
    openapi_url=f"{settings.API_V1_STR}/openapi.json"
)

# Add CORS middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Initialize services
hybrid_store = HybridStorageManager()
rag_service = RAGService()
schema_qa_service = SchemaQAService(hybrid_store)

app.include_router(health_router)
app.include_router(schema_upload_router)

@app.get("/")
async def root():
    return {"message": "Welcome to LangChain RAG API"}

@app.post("/upload")
async def upload_pdf(file: UploadFile = File(...)):
    try:
        if not file.filename:
            raise HTTPException(status_code=400, detail="No file provided")
        logger.info(f"Attempting to save file: {file.filename}")
        file_path = await save_upload_file(file)
        if not file_path:
            raise HTTPException(status_code=400, detail="Invalid file type. Only PDF files are allowed.")
        logger.info(f"File saved successfully at: {file_path}")
        logger.info("Processing PDF with QA service...")
        try:
            rag_service.qa_service.process_pdf(file_path)
            logger.info("PDF processed successfully")
            return {"message": "PDF processed successfully"}
        except Exception as e:
            logger.error(f"Error processing PDF: {str(e)}")
            raise HTTPException(status_code=500, detail=f"Error processing PDF: {str(e)}")
    except HTTPException as e:
        raise e
    except ValueError as e:
        logger.error(f"Error in upload_pdf: {str(e)}")
        raise HTTPException(status_code=400, detail=str(e))
    except Exception as e:
        logger.error(f"Error in upload_pdf: {str(e)}")
        raise HTTPException(status_code=500, detail=str(e))

@app.post("/schema/upload")
async def upload_schema(
    file: UploadFile = File(...),
    background_tasks: BackgroundTasks = None
) -> Dict:
    """Upload and process a schema file (SQL or JSON)."""
    try:
        # Read file content
        content = await file.read()
        file_content = content.decode('utf-8')
        
        # Get file extension
        file_extension = os.path.splitext(file.filename)[1].lower()
        
        # Process schema file
        schema_service = SchemaQAService()
        # Clear the schema vector store before adding new documents
        schema_service.hybrid_store.clear_store("schema")
        result = await schema_service.process_schema_file(file_content, file_extension)
        
        # Store documents in vector store synchronously
        if "documents" in result:
            await schema_service.store_documents(result["documents"])
        
        return {
            "message": "Schema file processed successfully",
            "schema_info": result.get("schema_info", {}),
            "file_type": file_extension[1:],  # Remove the dot
            "status": "success"
        }
        
    except Exception as e:
        logger.error(f"Error processing schema file: {str(e)}")
        raise HTTPException(
            status_code=500,
            detail=f"Error processing schema file: {str(e)}"
        )

@app.post("/ask")
async def ask_question(
    question: str = Query(None, description="Your question"),
    payload: dict = Body(None)
):
    # Prefer query param, fallback to JSON body
    if not question and payload:
        question = payload.get("question")
    if not question:
        raise HTTPException(status_code=422, detail="Missing 'question'.")
    try:
        logger.info(f"Received question: {question}")
        answer = rag_service.qa_service.ask_question(question)
        logger.info("Question answered successfully")
        return {"answer": answer}
    except ValueError as e:
        logger.error(f"Value error in ask_question: {str(e)}")
        raise HTTPException(status_code=400, detail=str(e))
    except Exception as e:
        logger.error(f"Error in ask_question: {str(e)}")
        raise HTTPException(status_code=500, detail=str(e))

@app.post("/schema/ask")
async def ask_schema_question(
    question: str = Query(None, description="Your question about the schema"),
    payload: dict = Body(None)
):
    """Ask questions about the database schema"""
    if not question and payload:
        question = payload.get("question")
    if not question:
        raise HTTPException(status_code=422, detail="Missing 'question'.")
    
    try:
        logger.info(f"Received schema question: {question}")
        answer, sources, similarity = await schema_qa_service.ask_schema_question(question)
        logger.info("Schema question answered successfully")
        return {
            "answer": answer,
            "sources": sources,
            "similarity": similarity
        }
    except Exception as e:
        logger.error(f"Error in ask_schema_question: {str(e)}")
        raise HTTPException(status_code=500, detail=str(e))

@app.get("/schema/summary")
async def get_schema_summary():
    """Get a summary of the processed schema"""
    try:
        summary = schema_qa_service.get_schema_summary()
        return summary
    except Exception as e:
        logger.error(f"Error getting schema summary: {str(e)}")
        raise HTTPException(status_code=500, detail=str(e))

@app.post("/reset_all")
async def reset_all():
    """
    Reset the entire RAG system, including:
    - Clear all uploaded files
    - Clear and reinitialize the vector store
    - Clear conversation memory
    - Verify the reset was successful
    """
    try:
        result = rag_service.reset_all()
        return {
            "status": "success",
            "message": result["message"],
            "verification": result["verification"],
            "timestamp": time.time()
        }
    except Exception as e:
        logger.error(f"Error in reset_all endpoint: {str(e)}")
        raise HTTPException(
            status_code=500,
            detail={
                "message": "Failed to reset system",
                "error": str(e),
                "timestamp": time.time()
            }
        )

@app.post("/refresh")
async def refresh():
    return rag_service.refresh()

def remove_old_schema_upload():
    pass 
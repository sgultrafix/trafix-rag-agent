import logging
from typing import Dict, List, Optional
import sqlparse
import sqlglot
from sqlglot import parse_one, exp

logger = logging.getLogger(__name__)

class SQLSchemaParser:
    """Service for parsing SQL schema files and extracting table/column information."""
    
    def __init__(self):
        self.logger = logging.getLogger(__name__)
    
    def parse_sql_file(self, sql_content: str) -> Dict:
        """
        Parse SQL content and extract schema information.
        
        Args:
            sql_content (str): The SQL file content
            
        Returns:
            Dict: Schema information including tables, columns, and relationships
        """
        try:
            # First pass: Use sqlparse for initial parsing
            parsed = sqlparse.parse(sql_content)
            
            # Second pass: Use sqlglot for more detailed analysis
            ast = parse_one(sql_content)
            
            schema_info = {
                "tables": [],
                "relationships": [],
                "columns": {}
            }
            
            # Extract table information
            for statement in parsed:
                if statement.get_type() == 'CREATE':
                    table_info = self._extract_table_info(statement)
                    if table_info:
                        schema_info["tables"].append(table_info)
            
            # Extract relationships using sqlglot
            for table in ast.find_all(exp.Table):
                table_name = table.name
                for column in table.find_all(exp.Column):
                    if isinstance(column.parent, exp.ForeignKey):
                        rel = {
                            "from_table": table_name,
                            "from_column": column.name,
                            "to_table": column.parent.references.table,
                            "to_column": column.parent.references.columns[0]
                        }
                        schema_info["relationships"].append(rel)
            
            return schema_info
            
        except Exception as e:
            self.logger.error(f"Error parsing SQL schema: {str(e)}")
            raise
    
    def _extract_table_info(self, statement) -> Optional[Dict]:
        """Extract table information from a CREATE statement."""
        try:
            # Extract table name
            table_name = None
            for token in statement.tokens:
                if token.ttype is None and token.value.upper() == 'TABLE':
                    # Next non-whitespace token should be the table name
                    for t in statement.tokens[statement.token_index(token) + 1:]:
                        if not t.is_whitespace:
                            table_name = t.value.strip('`"[]')
                            break
                    break
            
            if not table_name:
                return None
            
            # Extract column information
            columns = []
            for token in statement.tokens:
                if isinstance(token, sqlparse.sql.Identifier):
                    col_info = {
                        "name": token.get_name().strip('`"[]'),
                        "type": self._get_column_type(token),
                        "nullable": not any(t.value.upper() == 'NOT NULL' for t in token.tokens),
                        "primary_key": any(t.value.upper() == 'PRIMARY KEY' for t in token.tokens)
                    }
                    columns.append(col_info)
            
            return {
                "name": table_name,
                "columns": columns
            }
            
        except Exception as e:
            self.logger.error(f"Error extracting table info: {str(e)}")
            return None
    
    def _get_column_type(self, identifier) -> str:
        """Extract column type from an identifier token."""
        try:
            for token in identifier.tokens:
                if token.ttype is None and token.value.upper() in [
                    'INT', 'VARCHAR', 'TEXT', 'DATETIME', 'BOOLEAN', 'FLOAT',
                    'DOUBLE', 'DECIMAL', 'BLOB', 'JSON'
                ]:
                    return token.value.upper()
            return 'UNKNOWN'
        except Exception:
            return 'UNKNOWN' 
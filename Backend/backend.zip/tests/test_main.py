import pytest
from fastapi.testclient import TestClient
from unittest.mock import patch, MagicMock, AsyncMock
from app.main import app
import os
from pathlib import Path

client = TestClient(app)

@pytest.fixture
def mock_pdf_file(tmp_path):
    # Create a valid minimal PDF file
    pdf_path = tmp_path / "test.pdf"
    with open(pdf_path, "wb") as f:
        f.write(b"%PDF-1.4\n1 0 obj\n<< /Type /Catalog >>\nendobj\nxref\n0 1\n0000000000 65535 f \ntrailer\n<< /Root 1 0 R >>\nstartxref\n9\n%%EOF")
    return pdf_path

@pytest.fixture
def mock_uploads_dir(tmp_path):
    # Create a temporary uploads directory
    uploads_dir = tmp_path / "uploads"
    uploads_dir.mkdir()
    return uploads_dir

def test_root_endpoint():
    response = client.get("/")
    assert response.status_code == 200
    assert response.json() == {"message": "Welcome to LangChain RAG API"}

from pathlib import Path
TEST_PDF_PATH = Path("Testing_pdf_files/customsAct.pdf")
TEST_SCHEMA_PATH = Path("Testing_pdf_files/trading_schema.json")

# Update PDF upload test to use real PDF
@patch('app.services.rag_service.PDFQAService.process_pdf', return_value=True)
def test_upload_pdf_success(mock_process_pdf):
    with open(TEST_PDF_PATH, "rb") as f:
        test_content = f.read()
    files = {"file": ("customsAct.pdf", test_content, "application/pdf")}
    response = client.post("/upload", files=files)
    assert response.status_code == 200
    assert response.json()["message"] == "PDF processed successfully"

def test_upload_pdf_invalid_file():
    # Create a test text file
    test_content = b"test content"
    files = {"file": ("test.txt", test_content, "text/plain")}
    
    response = client.post("/upload", files=files)
    assert response.status_code == 400
    assert response.json() == {"detail": "Invalid file type. Only PDF files are allowed."}

@patch('app.services.rag_service.PDFQAService.ask_question', return_value="test answer")
def test_ask_question_success(mock_ask_question):
    response = client.post("/ask", json={"question": "test question"})
    assert response.status_code == 200
    assert response.json() == {"answer": "test answer"}

@patch('app.services.rag_service.PDFQAService.ask_question', side_effect=ValueError("No PDF has been processed yet"))
def test_ask_question_no_pdf_processed(mock_ask_question):
    response = client.post("/ask", json={"question": "test question"})
    assert response.status_code == 400
    assert response.json() == {"detail": "No PDF has been processed yet"}

@patch('app.services.rag_service.PDFQAService.ask_question', side_effect=Exception("Test error"))
def test_ask_question_error(mock_ask_question):
    response = client.post("/ask", json={"question": "test question"})
    assert response.status_code == 500
    # Accept either the default or custom error message
    assert response.json()["detail"] in ["An error occurred while processing your question", "Test error"]

def test_health_endpoint():
    response = client.get("/health")
    assert response.status_code == 200
    assert response.json() == {"status": "ok"}

# Update schema upload test to use real JSON schema
@patch('app.api.schema_upload.schema_qa_service.process_schema_file', return_value=True)
@patch('app.api.schema_upload.schema_qa_service.get_schema_summary', return_value={"tables": ["trades"], "relationships": [], "schema_types": ["json"]})
def test_upload_schema_success(mock_get_summary, mock_process_schema):
    with open(TEST_SCHEMA_PATH, "rb") as f:
        test_content = f.read()
    files = {"file": ("trading_schema.json", test_content, "application/json")}
    response = client.post("/schema/upload", files=files)
    assert response.status_code == 200
    assert response.json()["message"] == "Schema processed successfully"
    assert "schema_summary" in response.json()

@patch('app.main.schema_qa_service')
def test_upload_schema_invalid_type(mock_schema_qa):
    mock_file = MagicMock()
    mock_file.filename = "schema.txt"
    
    response = client.post("/schema/upload", files={"file": ("schema.txt", b"test", "text/plain")})
    assert response.status_code == 400
    assert "Invalid file type" in response.json()["detail"]

@patch('app.main.schema_qa_service')
def test_ask_schema_question_success(mock_schema_qa):
    mock_schema_qa.ask_schema_question = AsyncMock(return_value=("Test answer", [], 0.0))
    response = client.post("/schema/ask", json={"question": "What tables exist?"})
    assert response.status_code == 200
    assert response.json()["answer"] == "Test answer"
    assert response.json()["sources"] == []
    assert response.json()["similarity"] == 0.0

@patch('app.main.schema_qa_service')
def test_ask_schema_question_missing_question(mock_schema_qa):
    response = client.post("/schema/ask", json={})
    assert response.status_code == 422
    assert "Missing 'question'" in response.json()["detail"]

@patch('app.main.schema_qa_service')
def test_get_schema_summary_success(mock_schema_qa):
    mock_schema_qa.get_schema_summary.return_value = {
        "tables": ["users", "orders"],
        "relationships": [{"type": "foreign_key", "field": "user_id"}],
        "schema_types": ["sql"]
    }
    
    response = client.get("/schema/summary")
    assert response.status_code == 200
    assert len(response.json()["tables"]) == 2
    assert len(response.json()["relationships"]) == 1
    assert "sql" in response.json()["schema_types"]

@patch('app.main.schema_qa_service')
def test_get_schema_summary_error(mock_schema_qa):
    mock_schema_qa.get_schema_summary.side_effect = Exception("Test error")
    
    response = client.get("/schema/summary")
    assert response.status_code == 500
    assert "Test error" in response.json()["detail"] 
import os
import io
import json
import pytest
from fastapi.testclient import TestClient
from app.main import app
import tempfile
import yaml

client = TestClient(app)

@pytest.fixture(scope="module")
def minimal_schema_json():
    return json.dumps({
        "users": {
            "id": "integer",
            "name": "string"
        }
    })

@pytest.fixture(scope="module")
def second_schema_json():
    return json.dumps({
        "products": {
            "product_id": "integer",
            "product_name": "string"
        }
    })

@pytest.fixture(scope="module")
def minimal_pdf_bytes():
    # Create a minimal PDF in memory
    from reportlab.pdfgen import canvas
    from reportlab.lib.pagesizes import letter
    buffer = io.BytesIO()
    c = canvas.Canvas(buffer, pagesize=letter)
    c.drawString(100, 750, "This is a test PDF for LangChain RAG.")
    c.save()
    buffer.seek(0)
    return buffer.read()

def test_e2e_schema_upload_and_qa(minimal_schema_json, second_schema_json):
    # Upload first schema
    files = {"file": ("test_schema.json", minimal_schema_json, "application/json")}
    response = client.post("/schema/upload", files=files)
    assert response.status_code == 200
    assert "processed successfully" in response.json()["message"].lower()

    # Check vector store contents via /schema/summary
    summary_response = client.get("/schema/summary")
    assert summary_response.status_code == 200
    summary = summary_response.json()
    assert "users" in summary.get("tables", [])
    assert "json" in summary.get("schema_types", [])

    # Ask a question about the first schema
    question = "What fields does the users table have?"
    response = client.post("/schema/ask", json={"question": question})
    assert response.status_code == 200
    answer = response.json().get("answer", "").lower()
    assert "id" in answer and "name" in answer

    # Upload second schema
    files = {"file": ("test_schema2.json", second_schema_json, "application/json")}
    response = client.post("/schema/upload", files=files)
    assert response.status_code == 200
    assert "processed successfully" in response.json()["message"].lower()

    # Check vector store contents for second schema
    summary_response = client.get("/schema/summary")
    assert summary_response.status_code == 200
    summary = summary_response.json()
    assert "products" in summary.get("tables", [])
    assert "json" in summary.get("schema_types", [])

    # Ask a question about the second schema
    question = "What fields does the products table have?"
    response = client.post("/schema/ask", json={"question": question})
    assert response.status_code == 200
    answer = response.json().get("answer", "").lower()
    assert "product_id" in answer and "product_name" in answer

def test_e2e_pdf_upload_and_qa(minimal_pdf_bytes):
    # Upload PDF
    files = {"file": ("test.pdf", minimal_pdf_bytes, "application/pdf")}
    response = client.post("/upload", files=files)
    assert response.status_code == 200
    assert "processed successfully" in response.json()["message"].lower()

    # Ask a question about the PDF
    question = "What is written in the PDF?"
    response = client.post("/ask", json={"question": question})
    assert response.status_code == 200
    # The answer should mention 'test pdf' or similar
    answer = response.json().get("answer", "").lower()
    assert "test pdf" in answer or "langchain rag" in answer 